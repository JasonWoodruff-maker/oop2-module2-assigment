class Vehicle {
    constructor(make, model, color, year){
        this.make = make;
        this.model = model;
        this.year = year;
        this.color = color;

    }
}
class Car extends Vehicle{
    constructor(make, model, color, year, doors, milage){
        super(make, model, color, year)
        this.doors = doors;
        this.milage = milage;
        if (milage >= 10000) {
            this.condition = "Used";
        } else {
            this.condition = "New";
        };
    }

    vehicleDetails(){
        console.log("Color: " + this.color);
        console.log("Mileage: " + this.milage + " miles")
        console.log("Condition: " + this.condition)
        console.log("Make: " + this.make);
        console.log("Model: " + this.model);
        console.log("Year: " + this.year);
        console.log("Number of Doors: " + this.doors)
    }
}
